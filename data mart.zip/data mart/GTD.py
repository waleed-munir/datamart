#THIS SCRIPT PROCESSES THE Global Terrorism DataBase and inserts it into a PostgreSQL DB instance

# Cleaning and preprocessing the data in one DataFrame
import pandas as pd
import psycopg2

# Load the data into a DataFrame
filePath = 'globalterrorismdb_0522dist.xlsx'

# As the actual content of the CSV is not known an attempt will be made to load it with common settings
try:
    df = pd.read_excel(filePath, engine='openpyxl')
except Exception as e:
    # If the CSV contains any unusual formatting it will be caught here
    print(f"An error occurred while reading the CSV file: {e}")

#Step 1: Clean the date columns and create a Date column
df['Date'] = pd.to_datetime(df[['iyear', 'imonth', 'iday']].astype(str).agg('-'.join, axis=1), errors='coerce')
df = df.dropna(subset=['Date'])  # Drop rows with invalid dates

#Step 2: Clean the location related columns
#We'll ensure there are no missing values for these columns
df = df.dropna(subset=['country_txt', 'region_txt', 'city', 'latitude', 'longitude'])
df['latitude'] = df['latitude'].astype(float)
df['longitude'] = df['longitude'].astype(float)

#Step 3: Clean the attack type column
#Assuming 'attacktype1_txt' is already in the correct VARCHAR format, just ensure no nulls
df['attacktype1_txt'] = df['attacktype1_txt'].fillna('Unknown')

#Step4: Clean the target type column
#Assuming 'targtype1_txt' is already in the correct VARCHAR format, just ensure no nulls
df['targtype1_txt'] = df['targtype1_txt'].fillna('Unknown')

#Step 5: Clean the terrorist group name column ('gname')
df['gname'] = df['gname'].fillna('Unknown')

#Step 6: Process numerical columns for the fact table
#Convert numerical columns to appropriate types and handle missing values
df['nkill'] = df['nkill'].fillna(0).astype(int)
df['nwound'] = df['nwound'].fillna(0).astype(int)

#assume 'NumberOfAttackers' and 'EconomicImpact'
# are derived or estimated based on existing columns
df['NumberOfAttackers'] = df['nperps'].fillna(1).astype(int)  # Placeholder
df['EconomicImpact'] = df.apply(lambda row: min(10, row['nkill'] + row['nwound']), axis=1)  # Placeholder logic

#Assuming 'TotalDamageCost' is also not in the dataset, we'll use a placeholder value
df['TotalDamageCost'] = df['propvalue'].fillna(0).astype(float)

#Select the cleaned and preprocessed columns
cleaned_columns = [
    'Date', 'country_txt', 'region_txt', 'city', 'latitude', 'longitude',
    'attacktype1_txt', 'targtype1_txt', 'gname', 'nkill', 'nwound',
    'NumberOfAttackers', 'EconomicImpact', 'TotalDamageCost'
]

# Create a cleaned DataFrame with just the selected columns
cleaned_df = df[cleaned_columns].copy()

# Display the cleaned and preprocessed DataFrame
cleaned_df.head()


################## CONNECTING TO POSTGRES AND INSERTING CLEANED DATA ##################

#Your credentials may be different
conn = psycopg2.connect(host="localhost", dbname="datamart_db", user="postgres", password="1234", port=5432)
cursor = conn.cursor()

def fetch_economic_indicator_key(cursor, country, year):
    """
    Fetches the EconomicIndicatorKey from the EconomicIndicatorsDimension table
    based on the provided country and year
    """
    # Attempt to fetch the economic indicator key
    cursor.execute("""
        SELECT EconomicIndicatorKey
        FROM EconomicIndicatorsDimension
        WHERE Country = %s AND Year = %s;
    """, (country, year))
    result = cursor.fetchone()

    # Check if a result was found
    if result:
        return result[0]
    else:
        return None

#Inserts into DateTimeDimension and returns Key if a new row was added otherwise returns existing rows key
def get_or_insert_date(cursor, date):
    cursor.execute("SELECT DateKey FROM DateTimeDimension WHERE Date = %s;", (date,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        year, month, day = date.year, date.month, date.day
        debug_query = f"INSERT INTO DateTimeDimension (Year, Month, Day, Date) VALUES ({year}, {month}, {day}, '{date:%Y-%m-%d}') RETURNING DateKey;"
        cursor.execute(debug_query)
        return cursor.fetchone()[0]

#Inserts into LocationDimension and returns Key if a new row was added otherwise returns existing rows key
def get_or_insert_location(cursor, country, region, city, latitude, longitude):
    cursor.execute("SELECT LocationKey FROM LocationDimension WHERE Country = %s AND Region = %s AND City = %s;", (country, region, city))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        cursor.execute("INSERT INTO LocationDimension (Country, Region, City, Latitude, Longitude) VALUES (%s, %s, %s, %s, %s) RETURNING LocationKey;", (country, region, city, latitude, longitude))
        return cursor.fetchone()[0]

#Inserts into AttackTypeDimension and returns Key if a new row was added otherwise returns existing rows key
def get_or_insert_attack_type(cursor, attack_type_name):
    cursor.execute("SELECT AttackKey FROM AttackTypeDimension WHERE AttackTypeName = %s;", (attack_type_name,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        cursor.execute("INSERT INTO AttackTypeDimension (AttackTypeName) VALUES (%s) RETURNING AttackKey;", (attack_type_name,))
        return cursor.fetchone()[0]

#Inserts into TargetTypeDimension and returns Key if a new row was added otherwise returns existing rows key
def get_or_insert_target_type(cursor, target_type_name):
    cursor.execute("SELECT TargetKey FROM TargetTypeDimension WHERE TargetTypeName = %s;", (target_type_name,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        cursor.execute("INSERT INTO TargetTypeDimension (TargetTypeName) VALUES (%s) RETURNING TargetKey;", (target_type_name,))
        return cursor.fetchone()[0]

#Inserts into TerroristGroupDimension and returns Key if a new row was added otherwise returns existing rows key
def get_or_insert_terrorist_group(cursor, group_name):
    cursor.execute("SELECT TerroristGroupKey FROM TerroristGroupDimension WHERE GroupName = %s;", (group_name,))
    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        cursor.execute("INSERT INTO TerroristGroupDimension (GroupName) VALUES (%s) RETURNING TerroristGroupKey;", (group_name,))
        return cursor.fetchone()[0]

#Iterating over data frame and inserting into Postgres tables
for index, row in cleaned_df.iterrows():
    date_key = get_or_insert_date(cursor, row['Date'])
    location_key = get_or_insert_location(cursor, row['country_txt'], row['region_txt'], row['city'], row['latitude'], row['longitude'])
    attack_key = get_or_insert_attack_type(cursor, row['attacktype1_txt'])
    target_key = get_or_insert_target_type(cursor, row['targtype1_txt'])
    terrorist_group_key = get_or_insert_terrorist_group(cursor, row['gname'])
    
    economic_indicator_key = fetch_economic_indicator_key(cursor, row['country_txt'], row['Date'].year)
    
    cursor.execute("""
        INSERT INTO FactTerrorismIncidents (DateKey, LocationKey, AttackKey, TargetKey, TerroristGroupKey, EconomicIndicatorKey, NumberOfDeaths, NumberOfInjured, TotalDamageCost, NumberOfAttackers, EconomicImpact)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
    """, (date_key, location_key, attack_key, target_key, terrorist_group_key, economic_indicator_key, row['nkill'], row['nwound'], row['TotalDamageCost'], row['NumberOfAttackers'], row['EconomicImpact']))
    

conn.commit()

#Cleanup
cursor.close()
conn.close()