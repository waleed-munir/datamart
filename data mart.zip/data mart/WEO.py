import pandas as pd
import psycopg2
#THIS SCRIPT PROCESSES THE WEO DATASET AND INSERTS IT INTO A Postgres DB instance

# Load the economic indicators data from a CSV file
economic_indicators_path = 'WEOApr2021all.csv'
economic_indicators_df = pd.read_csv(economic_indicators_path)

# Clean and pivot the economic indicators data
# Filtering for specific WEO Subject Codes: NGDP, NGDPRPC, LUR, PCPIPCH
economic_indicators_df = economic_indicators_df[economic_indicators_df['WEO Subject Code'].isin(['NGDP', 'NGDPRPC', 'LUR', 'PCPIPCH'])]

# Transform the DataFrame to a long format to separate year and values into different columns
economic_indicators_long = economic_indicators_df.melt(id_vars=['ISO', 'Country', 'WEO Subject Code'],
                                                       var_name='Year', value_name='Value')

# Convert the 'Year' column to numeric, setting non-numeric values to NaN
economic_indicators_long['Year'] = pd.to_numeric(economic_indicators_long['Year'], errors='coerce')

# Drop rows where 'Year' is NaN to ensure data integrity
economic_indicators_long = economic_indicators_long.dropna(subset=['Year'])

# Define a function to clean values in the dataset
def clean_value(value):
    # If the value is a string and it equals '--', convert it to None
    if isinstance(value, str):
        if value == '--':
            return None  # Convert '--' to None, which will become NaN when cast to float
        value = value.replace(',', '')  # Remove commas from the string to avoid conversion errors
    # Convert the cleaned value to numeric, setting errors to NaN
    return pd.to_numeric(value, errors='coerce')  # Convert to float, coercing errors to NaN

# Apply the clean_value function to the 'Value' column to clean and convert all values
economic_indicators_long['Value'] = economic_indicators_long['Value'].apply(clean_value)

# Pivot the DataFrame to organize economic indicators by 'ISO', 'Country', and 'Year'
# This creates columns for each WEO Subject Code with their respective values
economic_indicators_pivoted = economic_indicators_long.pivot_table(index=['ISO', 'Country', 'Year'],
                                                                   columns='WEO Subject Code', values='Value',
                                                                   aggfunc='first').reset_index()

# Rename the WEO Subject Codes to more readable column names for clarity
economic_indicators_pivoted.rename(columns={'NGDP': 'GDP', 'NGDPRPC': 'GDPPerCapita', 'LUR': 'UnemploymentRate', 'PCPIPCH': 'InflationRate'}, inplace=True)

# Replace NaN values with None for SQL compatability
economic_indicators_pivoted = economic_indicators_pivoted.applymap(lambda x: None if pd.isna(x) else x)

# Display the first few rows of the pivoted and cleaned DataFrame
economic_indicators_pivoted.head()

# Connect to a PostgreSQL database using psycopg2
conn = psycopg2.connect(host="localhost", dbname="datamart_db", user="postgres", password="1234", port=5432)
cur = conn.cursor()

# SQL query template for inserting data into the EconomicIndicatorsDimension
sql = """
INSERT INTO EconomicIndicatorsDimension
(Country, Year, GDP, GDPPerCapita, UnemploymentRate, InflationRate)
VALUES (%s, %s, %s, %s, %s, %s);
"""

# Iterate through the DataFrame row by row for data insertion
for index, row in economic_indicators_pivoted.iterrows():
    # Extract row values to match the SQL query structure
    values = (
        row['Country'],
        row['Year'],
        row['GDP'],
        row['GDPPerCapita'],
        row['UnemploymentRate'],
        row['InflationRate']
    )

    # Execute the parameterized SQL query with the current row's values
    cur.execute(sql, values)

# Commit the transactions to the database
conn.commit()
